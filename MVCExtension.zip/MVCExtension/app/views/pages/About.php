<?php app_get_header('header'); ?>

<h1><?php echo $data['title']; ?></h1>
<h4><?php echo $data['description']; ?></h4>

<?php app_get_footer('footer'); ?>